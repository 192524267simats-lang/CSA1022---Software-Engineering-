import { useState } from "react"

type IconName = "arrow" | "bus" | "calendar" | "check" | "chevron" | "clock" | "location" | "minus" | "plus" | "search" | "shield" | "swap" | "users"

function Icon({ name, size = 20 }: { name: IconName size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: <path d="m9 18 6-6-6-6" />,
    bus: (
      <>
        <path d="M8 6v6m8-6v6M6 17h12M7 21v-2m10 2v-2M5 12h14" />
        <path d="M6 3h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z" />
      </>
    ),
    calendar: (
      <>
        <path d="M7 3v4m10-4v4M4 9h16" />
        <rect x="4" y="5" width="16" height="16" rx="2" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m6 9 6 6 6-6" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    location: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    minus: <path d="M5 12h14" />,
    plus: <path d="M12 5v14M5 12h14" />,
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    shield: (
      <>
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" />
        <path d="m9 12 2 2 4-4" />
      </>
    ),
    swap: <path d="m7 7-3 3 3 3m-3-3h16m-3 1 3 3-3 3m3-3H4" />,
    users: (
      <>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M19 8v6m3-3h-6" />
      </>
    ),
  }

  return (
    <svg
      aria-hidden="true"
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
      xmlns="http://www.w3.org/2000/svg"
    >
      <g
        stroke="currentColor"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.8"
      >
        {paths[name]}
      </g>
    </svg>
  )
}

const buses = [
  {
    name: "SwiftLine Express",
    type: "AC Sleeper • 2+1",
    depart: "07:30",
    arrive: "13:45",
    duration: "6h 15m",
    price: 34,
    seats: 12,
    rating: "4.8",
  },
  {
    name: "NorthStar Coaches",
    type: "Premium AC • 2+2",
    depart: "09:15",
    arrive: "15:50",
    duration: "6h 35m",
    price: 28,
    seats: 8,
    rating: "4.6",
  },
  {
    name: "BlueRoad Travels",
    type: "Executive Sleeper • 2+1",
    depart: "22:00",
    arrive: "04:10",
    duration: "6h 10m",
    price: 31,
    seats: 17,
    rating: "4.7",
  },
]

const unavailableSeats = ["1B", "2A", "3C", "4A", "5B", "6C"]

export default function App() {
  const [tripType, setTripType] = useState<"one" | "round">("one")
  const [from, setFrom] = useState("Boston")
  const [to, setTo] = useState("New York")
  const [passengers, setPassengers] = useState(1)
  const [searched, setSearched] = useState(false)
  const [selectedBus, setSelectedBus] = useState<number | null>(null)
  const [selectedSeats, setSelectedSeats] = useState<string[]>([])
  const [booked, setBooked] = useState(false)

  const swapCities = () => {
    setFrom(to)
    setTo(from)
  }

  const selectSeat = (seat: string) => {
    if (unavailableSeats.includes(seat)) return
    setSelectedSeats((current) =>
      current.includes(seat)
        ? current.filter((item) => item !== seat)
        : current.length < passengers
          ? [...current, seat]
          : current,
    )
  }

  const chooseBus = (index: number) => {
    setSelectedBus(index)
    setSelectedSeats([])
    setBooked(false)
    window.setTimeout(() => {
      document
        .querySelector("#seat-picker")
        ?.scrollIntoView({ behavior: "smooth", block: "start" })
    }, 50)
  }

  return (
    <main>
      <header className="nav">
        <div className="nav-inner">
          <button className="brand" onClick={() => setSearched(false)}>
            <span className="brand-mark">
              <Icon name="bus" size={22} />
            </span>
            <span>
              Route<span>ly</span>
            </span>
          </button>
          <nav>
            <a className="active" href="#search">
              Book a trip
            </a>
            <a href="#trips">My trips</a>
            <a href="#help">Help</a>
          </nav>
          <button className="account-button">JD</button>
        </div>
      </header>

      <section className="hero" id="search">
        <div className="hero-orb hero-orb-one" />
        <div className="hero-orb hero-orb-two" />
        <div className="hero-content">
          <div className="eyebrow">
            <span /> Reliable intercity travel
          </div>
          <h1>
            Your next journey,
            <br />
            <em>just a click away.</em>
          </h1>
          <p>Compare routes, choose your seat, and travel with confidence.</p>

          <div className="search-card">
            <div className="trip-tabs">
              <button
                className={tripType === "one" ? "selected" : ""}
                onClick={() => setTripType("one")}
              >
                One way
              </button>
              <button
                className={tripType === "round" ? "selected" : ""}
                onClick={() => setTripType("round")}
              >
                Round trip
              </button>
            </div>

            <div className="fields">
              <label className="field route-field">
                <span>From</span>
                <div>
                  <Icon name="location" size={19} />
                  <input
                    aria-label="Departure city"
                    onChange={(event) => setFrom(event.target.value)}
                    value={from}
                  />
                </div>
              </label>
              <button
                aria-label="Swap cities"
                className="swap-button"
                onClick={swapCities}
              >
                <Icon name="swap" size={17} />
              </button>
              <label className="field route-field">
                <span>To</span>
                <div>
                  <Icon name="location" size={19} />
                  <input
                    aria-label="Destination city"
                    onChange={(event) => setTo(event.target.value)}
                    value={to}
                  />
                </div>
              </label>
              <label className="field">
                <span>Departure</span>
                <div>
                  <Icon name="calendar" size={19} />
                  <input
                    aria-label="Departure date"
                    defaultValue="2026-05-24"
                    type="date"
                  />
                </div>
              </label>
              {tripType === "round" && (
                <label className="field">
                  <span>Return</span>
                  <div>
                    <Icon name="calendar" size={19} />
                    <input
                      aria-label="Return date"
                      defaultValue="2026-05-27"
                      type="date"
                    />
                  </div>
                </label>
              )}
              <div className="field passenger-field">
                <span>Travelers</span>
                <div>
                  <Icon name="users" size={19} />
                  <strong>
                    {passengers} {passengers === 1 ? "Adult" : "Adults"}
                  </strong>
                  <span className="passenger-actions">
                    <button
                      aria-label="Remove traveler"
                      onClick={() => setPassengers(Math.max(1, passengers - 1))}
                    >
                      <Icon name="minus" size={13} />
                    </button>
                    <button
                      aria-label="Add traveler"
                      onClick={() => setPassengers(Math.min(4, passengers + 1))}
                    >
                      <Icon name="plus" size={13} />
                    </button>
                  </span>
                </div>
              </div>
              <button
                className="search-button"
                onClick={() => {
                  setSearched(true)
                  setSelectedBus(null)
                  setBooked(false)
                  window.setTimeout(
                    () =>
                      document
                        .querySelector("#results")
                        ?.scrollIntoView({ behavior: "smooth" }),
                    50,
                  )
                }}
              >
                <Icon name="search" size={20} />
                Search buses
              </button>
            </div>
          </div>

          <div className="trust-row">
            <span>
              <Icon name="shield" size={18} /> Secure booking
            </span>
            <span>
              <Icon name="clock" size={18} /> Live schedules
            </span>
            <span>
              <Icon name="check" size={18} /> Free cancellation
            </span>
          </div>
        </div>
      </section>

      {searched ? (
        <section className="results-section" id="results">
          <div className="section-heading">
            <div>
              <span className="section-kicker">Available routes</span>
              <h2>
                {from} <span>to</span> {to}
              </h2>
              <p>
                Sunday, May 24 • {passengers}{" "}
                {passengers === 1 ? "traveler" : "travelers"}
              </p>
            </div>
            <button className="sort-button">
              Recommended <Icon name="chevron" size={15} />
            </button>
          </div>

          <div className="results-list">
            {buses.map((bus, index) => (
              <article className="bus-card" key={bus.name}>
                <div className="bus-identity">
                  <span className="bus-icon">
                    <Icon name="bus" size={21} />
                  </span>
                  <div>
                    <h3>{bus.name}</h3>
                    <p>{bus.type}</p>
                    <span className="rating">★ {bus.rating}</span>
                  </div>
                </div>
                <div className="timeline">
                  <div>
                    <strong>{bus.depart}</strong>
                    <span>{from}</span>
                  </div>
                  <div className="travel-line">
                    <span>{bus.duration}</span>
                    <i>
                      <b />
                      <b />
                    </i>
                    <small>Direct</small>
                  </div>
                  <div>
                    <strong>{bus.arrive}</strong>
                    <span>{to}</span>
                  </div>
                </div>
                <div className="price">
                  <span>From</span>
                  <strong>${bus.price}</strong>
                  <small>per person</small>
                </div>
                <div className="availability">
                  <span>{bus.seats} seats left</span>
                  <button onClick={() => chooseBus(index)}>
                    Select seats <Icon name="arrow" size={16} />
                  </button>
                </div>
              </article>
            ))}
          </div>

          {selectedBus !== null && (
            <section className="seat-panel" id="seat-picker">
              <div className="seat-heading">
                <div>
                  <span className="section-kicker">Almost there</span>
                  <h2>Choose your seat</h2>
                  <p>
                    {buses[selectedBus].name} • Select {passengers}{" "}
                    {passengers === 1 ? "seat" : "seats"}
                  </p>
                </div>
                <div className="legend">
                  <span>
                    <i className="available" /> Available
                  </span>
                  <span>
                    <i className="picked" /> Selected
                  </span>
                  <span>
                    <i className="occupied" /> Occupied
                  </span>
                </div>
              </div>

              <div className="seat-content">
                <div className="coach">
                  <div className="driver">
                    Front <span>◯</span>
                  </div>
                  <div className="seat-grid">
                    {Array.from({ length: 24 }, (_, i) => {
                      const row = Math.floor(i / 3) + 1
                      const letter = ["A", "B", "C"][i % 3]
                      const seat = `${row}${letter}`
                      const unavailable = unavailableSeats.includes(seat)
                      return (
                        <button
                          aria-label={`Seat ${seat}${
                            unavailable ? ", occupied" : ""
                          }`}
                          className={`${unavailable ? "occupied" : ""} ${
                            selectedSeats.includes(seat) ? "picked" : ""
                          } ${letter === "C" ? "aisle" : ""}`}
                          disabled={unavailable}
                          key={seat}
                          onClick={() => selectSeat(seat)}
                        >
                          {seat}
                        </button>
                      )
                    })}
                  </div>
                </div>

                <aside className="booking-summary">
                  {booked ? (
                    <div className="success-state">
                      <span>
                        <Icon name="check" size={28} />
                      </span>
                      <h3>Seats reserved!</h3>
                      <p>
                        Your trip is ready for checkout. A confirmation has been
                        added to My trips.
                      </p>
                      <button onClick={() => setBooked(false)}>
                        View trip summary
                      </button>
                    </div>
                  ) : (
                    <>
                      <h3>Trip summary</h3>
                      <div className="summary-route">
                        <span>{buses[selectedBus].depart}</span>
                        <i />
                        <span>{buses[selectedBus].arrive}</span>
                      </div>
                      <div className="summary-cities">
                        <span>{from}</span>
                        <span>{to}</span>
                      </div>
                      <dl>
                        <div>
                          <dt>Seats</dt>
                          <dd>
                            {selectedSeats.length
                              ? selectedSeats.join(", ")
                              : "Not selected"}
                          </dd>
                        </div>
                        <div>
                          <dt>Fare</dt>
                          <dd>
                            ${buses[selectedBus].price} × {passengers}
                          </dd>
                        </div>
                        <div>
                          <dt>Booking fee</dt>
                          <dd>$2</dd>
                        </div>
                      </dl>
                      <div className="total">
                        <span>Total</span>
                        <strong>
                          ${buses[selectedBus].price * passengers + 2}
                        </strong>
                      </div>
                      <button
                        className="continue-button"
                        disabled={selectedSeats.length !== passengers}
                        onClick={() => setBooked(true)}
                      >
                        {selectedSeats.length === passengers
                          ? "Continue to checkout"
                          : `Select ${passengers - selectedSeats.length} more`}
                        <Icon name="arrow" size={16} />
                      </button>
                      <small>
                        <Icon name="shield" size={14} /> Your selection is held
                        for 10 minutes
                      </small>
                    </>
                  )}
                </aside>
              </div>
            </section>
          )}
        </section>
      ) : (
        <section className="steps">
          <div className="section-heading centered">
            <span className="section-kicker">Easy as 1–2–3</span>
            <h2>Travel planning, simplified</h2>
          </div>
          <div className="step-grid">
            <article>
              <span>01</span>
              <Icon name="search" size={24} />
              <h3>Find your route</h3>
              <p>Explore schedules from trusted bus operators.</p>
            </article>
            <article>
              <span>02</span>
              <Icon name="bus" size={24} />
              <h3>Pick your seat</h3>
              <p>Choose exactly where you want to sit.</p>
            </article>
            <article>
              <span>03</span>
              <Icon name="check" size={24} />
              <h3>You're all set</h3>
              <p>Get your e-ticket instantly and start packing.</p>
            </article>
          </div>
        </section>
      )}

      <footer>
        <div className="brand">
          <span className="brand-mark">
            <Icon name="bus" size={18} />
          </span>
          <span>
            Route<span>ly</span>
          </span>
        </div>
        <p>© 2026 Routely. Built for better journeys.</p>
      </footer>
    </main>
  )
}
